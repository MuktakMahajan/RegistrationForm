import './App.css';
import { TutorForm } from './components/TutorForm';

function App() {
  return (
    <div className="App">
      <TutorForm/>
    </div>
  );
}

export default App;
